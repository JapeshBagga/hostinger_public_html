<!--<footer class="mainfooter text-center" role="contentinfo">-->
<!--    <div class="footer-middle">-->
<!--        <div class="container">-->
<!--            <div class="row text-center">-->
<!--                <div class="col-lg-6 col-md-3 col-sm-3 col-12">-->
                    <!--Column1-->
<!--                    <h4>Follow Us</h4>-->
<!--                    <p>Join millions of people who organize work and life with Jobaskit.</p>-->
<!--                    <ul class="social-network social-circle">-->
<!--                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fab fa-facebook"></i></a></li>-->
<!--                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fab fa-linkedin"></i></a></li>-->
<!--                        <li><a href="#" class="icoFacebook" title="Facebook"><i class="fab fa-instagram"></i></a></li>-->
<!--                        <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fab fa-twitter"></i></a></li>-->
<!--                    </ul>-->
<!--                </div>-->
<!--                <div class="col-lg-3 col-md-3 col-sm-3 col-6">-->
                    <!--Column2-->
<!--                    <div class="footer-pad">-->
<!--                        <h4 class="text-left">Features</h4>-->
<!--                        <ul class="list-unstyled text-left">-->
<!--                            <li><a href="#">How It Works</a></li>-->
<!--                            <li><a href="Ambassador.php">Campus Ambassador</a></li>-->
<!--                            <li><a href="#"></a>Events</li>-->
<!--                            <li><a href="#"></a>Pricing</li>-->
<!--                        </ul>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="col-lg-3 col-md-3 col-sm-3 col-6">-->
                    <!--Column3-->
<!--                    <div class="footer-pad">-->
<!--                        <h4 class="text-left">Resources</h4>-->
<!--                        <ul class="list-unstyled text-left">-->
<!--                            <li><a href="#">Channel Partners </a></li>-->
<!--                            <li><a href="#">Refer a Friend</a></li>-->
<!--                            <li><a href="#">Help Center</a></li>-->
<!--                            <li><a href="#">Placement Training</a></li>-->
<!--                            <li><a href="#">Integrations</a></li>-->

<!--                        </ul>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <h6 class="text-center mx-auto  pt-2">Copyright <i class="fas fa-copyright"></i> <span>2021-->
<!--                        Jobaskit</span> | All rights reserved.</h6>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</footer>-->

      
<head>
<link rel="stylesheet" href="studentpartner.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<footer class="mainfooter text-center" style="background-color: #ff9500;  margin-top:10px;" role="contentinfo">
    <div class="footer-middle">
        <div class="container">
            <div class="row text-center">
                <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                    <img src="images/jobaskit4.png" alt="" srcset="">
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                    <!--Column1-->
                    <h4>Follow Us</h4>
                    <p>Join millions of people who organize work and life with Jobaskit.</p>
                    <ul class="social-network social-circle">
                        <li><a href="https://www.facebook.com/JoBaskit/" class="icoFacebook" title="Facebook"><i class="fab fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/JoBaskit?s=08" class="icoLinkedin" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/jobaskit/" class="icoFacebook" title="Instagram"><i class="fab fa-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com/jobaskit/" class="icoLinkedin" title="Linkedin"><i
                                            class="fab fa-linkedin"></i></a></li>
                     
                    </ul>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                    <!--Column2-->
                    <div class="footer-pad">
                        <h4 class="text-left">Features</h4>
                        <ul class="list-unstyled text-left">
                            <li><a href="#">How It Works</a></li>
                            <li><a href="/HRStudentpartner-registration.php">Student HR Partner</a></li>
                            <li><a href="#">Events</a></li>
                            <li><a href="#">Pricing</a></li>
                            
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-3 col-6">
                    <!--Column3-->
                    <div class="footer-pad">
                        <h4 class="text-left">Resources</h4>
                        <ul class="list-unstyled text-left">
                            <li><a href="#">Refer an HR2 </a></li>
                            <li><a href="#">Refer a campus</a></li>
                            <li><a href="#">Help Center</a></li>
                            <li><a href="#">Placement Training</a></li>
                         
                        </ul>
                    </div>
                    
                </div>
               
                <h6 class="text-center mx-auto  pt-2">Copyright <i class="fas fa-copyright"></i> <span>2021
                        Jobaskit</span> | All rights reserved.</h6>
            </div>
        </div>
    </div>
    <script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
</footer>