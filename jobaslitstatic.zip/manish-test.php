<?php
    session_start();
    echo $_SESSION['email_test'];
    echo $_SESSION['name_test'];
?>