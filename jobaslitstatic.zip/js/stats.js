$('.counter').counterUp({
    delay: 15,
    time: 2000
});
