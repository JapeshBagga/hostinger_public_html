<!doctype html>
<?php
    require "php/connect.php";
    require "php/messageDisp.php";
    // require "php/preCommonHeader.php";
    // $hnewComp = "class='mm-active'";
    require "php/commonHeader.php";
?>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <h1 style="font-size: x-large; text-align: center;" class="card-title">Completed</h1>
                    <div class="row">
                        <div class="col-md-12">
                       
                            <div class="mb-3 mt-3 ml-5  text-center card card-body"
                                style="width: 900px; height: 250px;">
                                <h1 style="font-size: large; text-align: center;" class="card-title">Software Enginner</h1>
                                <hr>
                                <div class="headingEdit2" style="text-align: center;">
                                    <ul>
                                        <li style="list-style: none;"><span style="font-size: 1.2rem;">No. of applied
                                                candidates</span>: 40</li>
                                        <li style="list-style: none;"><span style="font-size: 1.2rem;">No. of Selected
                                                candidates</span>: 30</li>
                                        <li style="list-style: none;"><span style="font-size: 1.2rem;">Total</span>: 40
                                        </li>
                                    </ul>
                                </div>
                                <p class="mt-1" style="visibility: hidden;"><span style="font-weight: 600;">
                                        Description:&nbsp;</span>Experience with modern development practices and
                                    processes: use of source code controlthe Joint Entrance Examination – Advanced.</p>



                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                       
                            <div class="mb-3 mt-3 ml-5  text-center card card-body"
                                style="width: 900px; height: 250px;">
                                <h1 style="font-size: large; text-align: center;" class="card-title">Software Enginner</h1>
                                <hr>
                                <div class="headingEdit2" style="text-align: center;">
                                    <ul>
                                        <li style="list-style: none;"><span style="font-size: 1.2rem;">No. of applied
                                                candidates</span>: 40</li>
                                        <li style="list-style: none;"><span style="font-size: 1.2rem;">No. of Selected
                                                candidates</span>: 30</li>
                                        <li style="list-style: none;"><span style="font-size: 1.2rem;">Total</span>: 40
                                        </li>
                                    </ul>
                                </div>
                                <p class="mt-1" style="visibility: hidden;"><span style="font-weight: 600;">
                                        Description:&nbsp;</span>Experience with modern development practices and
                                    processes: use of source code controlthe Joint Entrance Examination – Advanced.</p>



                            </div>
                        </div>
                    </div>





                </div>
                <div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                            <p>All rights Reversed</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="./assets/scripts/main.js"></script>
</body>

</html>