<!doctype html>
<?php
    require "php/connect.php";
    require "php/messageDisp.php";
    // require "php/preCommonHeader.php";
    // $hnewComp = "class='mm-active'";
    require "php/commonHeader.php";
?>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <table id="example" class="table table-striped table-bordered dt-responsive nowrap twoDes "
                        style="width:100%; background-color:white;">
                        <thead>
                            <tr>
                                <th>First name</th>
                                <th>Last name</th>
                                <th>E-mail</th>
                                <th>Contact No.</th>
                                <th>College Name</th>
                                <th>College ID No.</th>
                                <th>Skills</th>
                                <th>Job Applied for</th>
                                <th>Shortlisted</th>
                                <th>Selected</th>
                                <th>Rejected</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>


                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>
                            <tr>
                                <td><i class="fas fa-plus-square hid"></i><a href="studentProfile.html">Aadesh</a></td>
                                <td><a href="studentProfile.html">Sharma</a></td>
                                <td>aadesh@gmail.net</td>
                                <td>9876543210</td>
                                <td>IIT Bhilai</td>
                                <td>4442345</td>
                                <td>Reactjs,MERN,HTML</td>
                                <td>Frontend</td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>
                                <td><button type="button" class="btn btn-info"
                                        style="margin-right: 2%;">Yes</button><button type="button"
                                        class="btn btn-info">No</button></td>

                            </tr>



                        </tbody>
                    </table>


                </div>
                <footer>
                    <div class="app-wrapper-footer">
                        <div class="app-footer">
                            <div class="app-footer__inner">
                                <p>All rights Reversed</p>

                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="./assets/scripts/main.js"></script>
    <!--Table-->
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            var table = $('#example').DataTable({
                lengthChange: false,
                buttons: ['copy', 'excel', 'csv', 'pdf', 'colvis']
            });

            table.buttons().container()
                .appendTo('#example_wrapper .col-md-6:eq(0)');
        });
    </script>

</body>

</html>