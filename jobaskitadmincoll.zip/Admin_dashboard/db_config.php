<?php
	$dbHost = "database-1.cawkcllqzbpg.ap-south-1.rds.amazonaws.com";
	$dbDatabase = "admindashboard";
	$dbPasswrod = "M=7t-pDLQHGSgoNdbcFujjst9&)kAwou";
	$dbUser = "admin";
	$mysqli = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
?>