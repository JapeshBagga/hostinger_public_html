<?php
    require_once "identification.php";
    $email1 = $_SESSION["email"];
    $user_name=$row['name'];
    // $intro_query = "select * from proforma where email = $email1";
    // $intro_result=mysqli_query($conn, $intro_query);
    // if(mysqli_num_rows($intro_result) >0){
    // 	$intro_query="insert into introduction (intro_login_id) values ('$login_id')";
    // 	mysqli_query($conn, $intro_query);
    // }
    if(isset($_POST['submit'])){
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone_number']);
        $email = mysqli_real_escape_string($conn, $_POST['email_id']);
        $location = mysqli_real_escape_string($conn, $_POST['location']);
        $preferred_work_locations	= mysqli_real_escape_string($conn, $_POST['preferred_work_locations']);
        $objective = mysqli_real_escape_string($conn, $_POST['objective']);
        
        $experience = mysqli_real_escape_string($conn, $_POST['experience']);
        $job_title = mysqli_real_escape_string($conn, $_POST['job_title']);
        $name_of_the_organisation = mysqli_real_escape_string($conn, $_POST['name_of_the_organisation']);
        //$location = mysqli_real_escape_string($conn, $_POST['up_married']);
        $starting_from = mysqli_real_escape_string($conn, $_POST['starting_from']);
        $ending_in = mysqli_real_escape_string($conn, $_POST['ending_in']);
        $roles_and_responsibilities = mysqli_real_escape_string($conn, $_POST['roles_and_responsibilities']);
        
        $education = mysqli_real_escape_string($conn, $_POST['education']);
        $college_name = mysqli_real_escape_string($conn, $_POST['college_name']);
        $college_university_autonomous = mysqli_real_escape_string($conn, $_POST['college_university_autonomous']);
        $college_affiliated_to_university = mysqli_real_escape_string($conn, $_POST['college_affiliated_to_university']);
        $degree = mysqli_real_escape_string($conn, $_POST['degree']);
        
        $pg_degree_details  = mysqli_real_escape_string($conn, $_POST['pg_degree_details']);
        $ug_degree_details  = mysqli_real_escape_string($conn, $_POST['ug_degree_details']);
        $specialisation = mysqli_real_escape_string($conn, $_POST['specialisation']);
        
        $year_of_passing = mysqli_real_escape_string($conn, $_POST['year_of_passing']);
        $CGPA_percentage_obtained = mysqli_real_escape_string($conn, $_POST['CGPA_percentage_obtained']);
        
        $honors_and_awards = mysqli_real_escape_string($conn, $_POST['honors_and_awards']);
        $title_of_award = mysqli_real_escape_string($conn, $_POST['title_of_award']);
        $issued_by = mysqli_real_escape_string($conn, $_POST['issued_by']);
        $issued_in_year = mysqli_real_escape_string($conn, $_POST['issued_in_year']);
        
        $academic_certification = mysqli_real_escape_string($conn, $_POST['academic_certification']);
        $name_of_the_certificate = mysqli_real_escape_string($conn, $_POST['name_of_the_certificate']);
        $name_of_the_issuing_organisation = mysqli_real_escape_string($conn, $_POST['name_of_the_issuing_organisation']);
        $date_of_issue = mysqli_real_escape_string($conn, $_POST['date_of_issue']);
        
        $projects_research_experience = mysqli_real_escape_string($conn, $_POST['projects_research_experience']);
        $project_title = mysqli_real_escape_string($conn, $_POST['project_title']);
        $project_description = mysqli_real_escape_string($conn, $_POST['project_description']);
        $year = mysqli_real_escape_string($conn, $_POST['year']);
        
        $use_cases = mysqli_real_escape_string($conn, $_POST['use_cases']);
        $advisor = mysqli_real_escape_string($conn, $_POST['advisor']);
        $published_in = mysqli_real_escape_string($conn, $_POST['published_in']);
        $place_of_the_project = mysqli_real_escape_string($conn, $_POST['place_of_the_project']);
        
        $journal_papers_accepted = mysqli_real_escape_string($conn, $_POST['journal_papers_accepted']);
        $journal_papers_review = mysqli_real_escape_string($conn, $_POST['journal_papers_review']);
        
        $conference_papers  = mysqli_real_escape_string($conn, $_POST['conference_papers']);
        $patent = mysqli_real_escape_string($conn, $_POST['patent']);
        $inventor_lastname = mysqli_real_escape_string($conn, $_POST['inventor_lastname']);
        $inventor_firstname = mysqli_real_escape_string($conn, $_POST['inventor_firstname']);
        $up_work_end = mysqli_real_escape_string($conn, $_POST['up_work_end']);
        $up_work_desc = mysqli_real_escape_string($conn, $_POST['up_work_desc']);
        
        $title_of_invention = mysqli_real_escape_string($conn, $_POST['title_of_invention']);
        $patent_office = mysqli_real_escape_string($conn, $_POST['patent_office']);
        $patent_no = mysqli_real_escape_string($conn, $_POST['patent_no']);
        
        $professional_training = mysqli_real_escape_string($conn, $_POST['professional_training']);
        $seminar_or_workshop = mysqli_real_escape_string($conn, $_POST['seminar_or_workshop']);
        $name_of_institution = mysqli_real_escape_string($conn, $_POST['name_of_institution']);
        $institution_location = mysqli_real_escape_string($conn, $_POST['institution_location']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $validity = mysqli_real_escape_string($conn, $_POST['validity']);
        
        $professional_affiliations = mysqli_real_escape_string($conn, $_POST['professional_affiliations']);
        $name_of_organization = mysqli_real_escape_string($conn, $_POST['name_of_organization']);
        $year_to_year = mysqli_real_escape_string($conn, $_POST['year_to_year']);
        $description_of_role_or_responsibilities = mysqli_real_escape_string($conn, $_POST['description_of_role_or_responsibilities']);
        
        
        $position_of_responsibility  = mysqli_real_escape_string($conn, $_POST['position_of_responsibility']);
        $extracurricular_activities = mysqli_real_escape_string($conn, $_POST['extracurricular_activities']);
        $languages = mysqli_real_escape_string($conn, $_POST['languages']);
        $hobbies = mysqli_real_escape_string($conn, $_POST['hobbies']);
        
        // Setting up the timezone.
        date_default_timezone_set('Asia/Calcutta');
        $date=date("d M Y");
        $time=date("H:i A");
        $up_date = $time." ".$date;
        
        $up_query = "insert into proforma(name,phone,email,location,preferred_work_locations,objective,experience,
        job_title,name_of_the_organisation,starting_from,ending_in,roles_and_responsibilities,education,college_name,college_university_autonomous,
        college_affiliated_to_university,degree,pg_degree_details,ug_degree_details,specialisation,year_of_passing,CGPA_percentage_obtained,
        honors_and_awards,title_of_award,issued_by,issued_in_year, academic_certification,name_of_the_certificate,name_of_the_issuing_organisation,
        date_of_issue,projects_research_experience,project_title,project_description,year,use_cases,advisor,published_in,
        place_of_the_project,journal_papers_accepted,journal_papers_review,conference_papers,patent,inventor_lastname,inventor_firstname,
        up_work_end,up_work_desc,title_of_invention,patent_office,patent_no,professional_training,seminar_or_workshop,name_of_institution,institution_location,date,
        description,validity,professional_affiliations,name_of_organization,year_to_year,description_of_role_or_responsibilities,
        position_of_responsibility,extracurricular_activities,languages,hobbies) values ('$name','$phone','$email','$location','$preferred_work_location','$objective', '$experience','$job_title','$name_of_the_organisation','$starting_from','$ending_in','$roles_and_responsibilities','$education','$college_name','$college_university_autonomous','$college_affiliated_to_university', '$degree','$pg_degree_detail','$ug_degree_details','$specialisation','$year_of_passing','$CGPA_percentage_obtained', '$honors_and_awards','$title_of_award','$issued_by','$issued_in_year','$academic_certification','$name_of_the_certificate', '$name_of_the_issuing_organisation','$date_of_issue','$projects_research_experience','$project_title','$project_description','$year','$use_cases','$advisor','$published_in','$place_of_the_project','$journal_papers_accepted','$journal_papers_review','$conference_papers','$patent','$inventor_lastname','$inventor_firstname', '$up_work_end','$up_work_desc', '$title_of_invention','$patent_office','$patent_no','$professional_training','$seminar_or_workshop','$name_of_institution','$institution_location','$date','$description','$validity','$professional_affiliations','$name_of_organization','$year_to_year','$description_of_role_or_responsibilities','$position_of_responsibility','$extracurricular_activities','$languages','$hobbies')";
        
    	if(mysqli_query($conn, $up_query))
		    echo "<script>alert('Successfull');</script>";
	    else
		    echo "<script>alert('Try Again, error in insert query');</script>";
    //      $up_query = "update proforma set
    // 	name='$name',phone='$phone',email='$email',location='$location',preferred_work_locations='$preferred_work_location',objective='$objective',
    // 	experience='$experience',job_title='$job_title',name_of_the_organisation='$name_of_the_organisation',starting_from='$starting_from',ending_in='$ending_in',
    
    // 	roles_and_responsibilities='$roles_and_responsibilities',education='$education',college_name='$college_name',college_university_autonomous='$college_university_autonomous',college_affiliated_to_university='$college_affiliated_to_university',
    // 	degree='$degree',pg_degree_details='$pg_degree_details',ug_degree_details='$ug_degree_details',specialisation='$specialisation',year_of_passing='$year_of_passing',CGPA_percentage_obtained='$CGPA_percentage_obtained',
    // 	honors_and_awards='$honors_and_awards',title_of_award='$title_of_award',issued_by='$issued_by',issued_in_year='$issued_in_year',academic_certification='$academic_certification',name_of_the_certificate='$name_of_the_certificate',
    // 	name_of_the_issuing_organisation='$name_of_the_issuing_organisation',date_of_issue='$date_of_issue',projects_research_experience='$projects_research_experience',project_title='$project_title',project_description='$project_description',year='$year',
    // 	use_cases='$use_cases',advisor='$advisor',published_in='$published_in',place_of_the_project='$place_of_the_project',journal_papers_accepted='$journal_papers_accepted',journal_papers_review='$journal_papers_review',
    // 	conference_papers='$conference_papers',patent='$patent',inventor_lastname='$inventor_lastname',inventor_firstname='$inventor_firstname',
    // 	up_work_end='$up_work_end',up_work_desc='$up_work_desc',
    // 	title_of_invention='$title_of_invention',patent_office='$patent_office',patent_no='$patent_no',
    //     professional_training='$professional_training',seminar_or_workshop='$seminar_or_workshop',name_of_institution='$name_of_institution',location='$location',date='$date',description='$description',
    //     validity='$validity',professional_affiliations='$professional_affiliations',name_of_organization='$name_of_organization',year_to_year='$year_to_year',description_of_role_or_responsibilities='$description_of_role_or_responsibilities',position_of_responsibility='$position_of_responsibility',
    //     extracurricular_activities='$extracurricular_activities',languages='$languages',hobbies='$hobbies',institution_location'=$institution_location'
    //     where (proforma_id='$prodorma_id')";
    
    // 	if(mysqli_query($conn, $up_query)){
    // 		header('location:registration.php');
    // 	}
    //     else{
    //         $msg = "ERROR: Could not execute query: $up_query. " . mysqli_error($conn);
    //         echo "<script type=\"text/javascript\">alert(\"$msg\");</script>";
    //     }
    }
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Registeration | JoBaskit</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="http://code.jquery.com/jquery-1.9.0.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.js"></script>
  <script src="http://ajax.microsoft.com/ajax/jquery.validate/1.5.5/jquery.validate.min.js"></script>

  <?php require_once 'requires/top-scripts.php' ?>
  <style>
    .dz-message {
      padding:2rem 1rem;
    }


  </style>
  <style>
        @import url("https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap");

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            list-style: none;
            font-family: "Montserrat", sans-serif;
        }

        body {
            background: #f3f2f0;
        }

        .wrapper {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .registration_form {
            background: #f78325;
            padding: 56px 96px;
            border-radius: 5px;
            width: 100%;
        }

        .registration_form .title {
            text-align: center;
            font-size: 24px;
            text-transform: uppercase;
            color: #070707;
            letter-spacing: 5px;
            font-weight: 700;
        }

        .form_wrap {
            margin-top: 35px;
        }

        .form_wrap h4 {
            padding-bottom: 15px;
            padding-top: 5px;
        }

        .form_wrap .input_wrap {
            margin-bottom: 15px;
        }

        .form_wrap .input_wrap:last-child {
            margin-bottom: 0;
        }

        .form_wrap .input_wrap label {
            display: block;
            margin-bottom: 3px;
            color: #020202;
        }

        .form_wrap .input_wrap .job {
            padding-bottom: 10px;
        }

        .form_wrap .input_grp1 {
            display: flex;
            justify-content: space-between;
        }

        .input_grp2 {
            display: flex;
            justify-content: space-between;
        }

        .input_grp3 {
            display: flex;
            justify-content: space-between;
        }

        .form_wrap .input_grp1 input[type="text"] {
            width: 220px;
        }

        .form_wrap .input_grp2 input[type="text"] {
            width: 360px;
        }

        .form_wrap .input_grp2 input[type="email"] {
            width: 360px;
        }

        .form_wrap .input_grp2 input[type="radio"] {
            width: 360px;
        }

        .form_wrap .input_grp3 input[type="text"] {
            width: 360px;
        }

        .form_wrap .input_grp3 input[type="date"] {
            width: 360px;
            height: 45px;
        }

        .form_wrap input[type="text"] {
            width: 100%;
            border-radius: 3px;
            border: 1px solid #9597a6;
            padding: 10px;
            outline: none;
        }

        .form_wrap input[type="email"] {
            width: 100%;
            border-radius: 3px;
            border: 1px solid #9597a6;
            padding: 10px;
            outline: none;
        }

        .form_wrap input[type="text"]:focus {
            border-color: #ebd0ce;
        }



        .form_wrap .submit_btn {
            width: 25%;
            background: #380f03;
            padding: 10px;
            border: 0;
            border-radius: 3px;
            text-transform: uppercase;
            letter-spacing: 3px;
            cursor: pointer;
            color: aliceblue;
            opacity: 70%;
        }

        .form_wrap .submit_btn:hover {
            background: #0e0300;
        }
    </style>

</head>
<body>
   <!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">

      <!----LOGO CODE or BRAND-->
      <?php require_once 'requires/logo.php' ?>

      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="leaderboard.php">
                <i class="ni ni-tv-2"></i>
                <span class="nav-link-text">Leaderboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="introduction.php">
                <i class="ni ni-single-02"></i>
                <span class="nav-link-text">Self-Introduction</span>
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="aptitude-quizes.php">
                <i class="ni ni-bullet-list-67"></i>
                <span class="nav-link-text">Quizes</span>
              </a>
        </div>
      </div>
    </div>
  </nav>

  <!-- Main content -->
  <div class="main-content" id="panel">
    <!-- Topnav -->
    <nav class="navbar navbar-top navbar-expand navbar-dark bg-default border-bottom">
      <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <!-- Navbar links -->
          <ul class="navbar-nav align-items-center  ml-md-auto ">
            <li class="nav-item d-xl-none">
              <!-- Sidenav toggler -->
              <div class="pr-3 sidenav-toggler sidenav-toggler-dark" data-action="sidenav-pin" data-target="#sidenav-main">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </div>
            </li>
            <li class="nav-item d-sm-none">
              <a class="nav-link" href="#" data-action="search-show" data-target="#navbar-search-main">
                <i class="ni ni-zoom-split-in"></i>
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ni ni-bell-55"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-xl  dropdown-menu-right  py-0 overflow-hidden">
                <!-- Dropdown header -->
                <div class="px-3 py-3">
                  <h6 class="text-sm text-muted m-0">You have <strong class="text-primary">13</strong> notifications.</h6>
                </div>
                <!-- List group -->
                <div class="list-group list-group-flush">
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="img/theme/team-1.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">Japesh</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>2 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="img/theme/team-2.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>3 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="img/theme/team-3.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>5 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Your posts have been liked a lot.</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="img/theme/team-4.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>2 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">Let's meet at Starbucks at 11:30. Wdyt?</p>
                      </div>
                    </div>
                  </a>
                  <a href="#!" class="list-group-item list-group-item-action">
                    <div class="row align-items-center">
                      <div class="col-auto">
                        <!-- Avatar -->
                        <img alt="Image placeholder" src="img/theme/team-5.jpg" class="avatar rounded-circle">
                      </div>
                      <div class="col ml--2">
                        <div class="d-flex justify-content-between align-items-center">
                          <div>
                            <h4 class="mb-0 text-sm">John Snow</h4>
                          </div>
                          <div class="text-right text-muted">
                            <small>3 hrs ago</small>
                          </div>
                        </div>
                        <p class="text-sm mb-0">A new issue has been reported for Argon.</p>
                      </div>
                    </div>
                  </a>
                </div>
                <!-- View all -->
                <a href="#!" class="dropdown-item text-center text-primary font-weight-bold py-3">View all</a>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="ni ni-ungroup"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-lg dropdown-menu-dark bg-default  dropdown-menu-right ">
                <div class="row shortcuts px-4">
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-red">
                      <i class="ni ni-calendar-grid-58"></i>
                    </span>
                    <small>Calendar</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-orange">
                      <i class="ni ni-email-83"></i>
                    </span>
                    <small>Email</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-info">
                      <i class="ni ni-credit-card"></i>
                    </span>
                    <small>Payments</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-green">
                      <i class="ni ni-books"></i>
                    </span>
                    <small>Reports</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-purple">
                      <i class="ni ni-pin-3"></i>
                    </span>
                    <small>Maps</small>
                  </a>
                  <a href="#!" class="col-4 shortcut-item">
                    <span class="shortcut-media avatar rounded-circle bg-gradient-yellow">
                      <i class="ni ni-basket"></i>
                    </span>
                    <small>Shop</small>
                  </a>
                </div>
              </div>
            </li>
          </ul>
          <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
            <li class="nav-item dropdown">
              <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                    <i class="ni ni-single-02"></i>
                  <div class="media-body  ml-2  d-none d-lg-block">
                    <span class="mb-0 text-sm  font-weight-bold"><?php echo $user_name;?></span>
                  </div>
              </div>
              </a>
              <div class="dropdown-menu  dropdown-menu-right ">
                <div class="dropdown-header noti-title">
                  <h6 class="text-overflow m-0">Welcome!</h6>
                </div>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-single-02"></i>
                  <span>My profile</span>
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-settings-gear-65"></i>
                  <span>Settings</span>
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-calendar-grid-58"></i>
                  <span>Activity</span>
                </a>
                <a href="#!" class="dropdown-item">
                  <i class="ni ni-support-16"></i>
                  <span>Support</span>
                </a>
                <div class="dropdown-divider"></div>
                <a href="logout.php" class="dropdown-item">
                  <i class="ni ni-user-run"></i>
                  <span>Logout</span>
                </a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
    <div class="header pb-6 d-flex align-items-center" style="min-height: 150px; background-image: url(img/theme/profile-cover.jpg); background-size: cover; background-position: center top;">
      <!-- Mask -->
      <span class="mask bg-gradient-default opacity-8"></span>
      <!-- Header container -->
      <div class="container-fluid d-flex align-items-center">
        <div class="row text-center">
          <div class="col-md-12">
            <h1 class="text-white">Student Proforma</h1>
        <!-- <p class="text-white mt-0 mb-5">This is your profile page. You can see the progress you've made with your work and manage your projects or assigned tasks</p>
            <a href="#!" class="btn btn-neutral">Edit profile</a> -->
          </div>
        </div>
      </div>
    </div>

    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12 order-xl-2">
          <div class="card">
            <div class="">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0"></h3>
                </div>
                <!-- <div class="col-4 text-right">
                  <a href="#!" class="btn btn-sm btn-primary">Settings</a>
                </div> -->
              </div>
            </div>


            <div class="">
                <!--<h6 class="heading-small text-muted mb-4">Personal information</h6>-->
                <div class="wrapper">
    <div></div>

        <div class="registration_form">


            <form id="addForm" name="addForm" action="" method="post" enctype="multipart/form-data">
                <div class="form_wrap">
                    <h4> <strong> Personal Information</strong></h4>
                    <div class="input_grp3">
                        <div class="input_wrap">
                            <label for="name">Name</label>
                            <input type="text" placeholder="name" id="name" name="name">
                        </div>
                        <div class="input_wrap">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" placeholder="phone_number" id="phone_number" name="phone_number">
                        </div>

                    </div>
                    <div class="input_grp2">
                        <div class="input_wrap">
                            <label for="email_id">Email Address</label>
                            <input type="email" placeholder="email_id" id="email_id" name="email_id">
                        </div>
                        <div class="input_wrap">
                            <label for="location">Location</label>
                            <input type="text" placeholder="location" id="location" name="location">
                        </div>
                    </div>
                    <div class="input_grp3">
                        <div class="input_wrap">
                            <label for="location">Preferred Work locations</label>
                            <input type="text" placeholder="preferred_work_locations" id="preferred_work_locations" name="preferred_work_locations">
                        </div>
                        <div class="input_wrap">
                            <label for="objective">Objective</label>
                            <input type="text" placeholder="objective" id="obj" name="objective">
                        </div>
                    </div>

                    <hr class="my-5">

                    <h4><strong>Experience</strong></h4>

                    <div class="input_wrap">
                        <div class="job">
                            <label for="job">Job Title</label>
                            <input type="text" placeholder="job_title" id="job_title" name="job_title">
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="org">Name Of Organisation</label>
                                <input type="text" placeholder="name_of_organisation" id="name_of_the_organisation" name="name_of_the_organisation">
                            </div>
                            <div class="input_wrap">
                                <label for="location">Location</label>
                                <input type="text" placeholder="location" id="location" name="location">
                            </div>
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="start">Starting From</label>
                                <input type="date" id="starting_from" name="starting_from">
                            </div>
                            <div class="input_wrap">
                                <label for="end">Ending in</label>
                                <input type="date" id="ending_in" name="ending_in">
                            </div>
                        </div>
                        <div class="input_wrap">
                            <label for="roles">Roles and Responsibilities</label>
                            <textarea name="roles" id="roles_and_responsibilities" placeholder="roles_and_responsibilities" cols="82" rows="3"></textarea>
                        </div>

                    </div>

                    <hr class="my-5">
                    <h4><strong>Education</strong></h4>
                    <div class="input_wrap" id="adding_element">
                        <div class="job">
                            <label for="job">College Name</label>
                            <input type="text" placeholder="college_name" id="college_name">
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Information">College/University/Autonomous</label>
                                <input type="text" placeholder="college_university_autonomous" id="college_university_autonomous" name="college_university_autonomous">
                            </div>
                            <div class="input_wrap">
                                <label for="college_affiliated_to_university">College – Affiliated to</label>
                                <input type="text" placeholder="university" id="college_affiliated_to_university" name="college_affiliated_to_university">
                            </div>
                        </div>
                        <label for="Information"> <h5> Degree</h5></label>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Information">PG Degree Details</label>
                                <input type="text" placeholder="pg_details" id="pg_degree_details" name="pg_degree_details">
                            </div>
                            <div class="input_wrap">
                                <label for="university">UG Degree Details</label>
                                <input type="text" placeholder="ug_details" id="ug_degree_details" name="ug_degree_details">
                            </div>

                        </div>
                        <div class="input_wrap">
                            <div class="job">
                                <label for="job">Specialisation</label>
                                <input type="text" placeholder="specialisation" id="specialisation" name="specialisation">
                            </div>

                        </div>

                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Information">Year of Passing</label>
                                <input type="text" placeholder="year_of_passing" id="year_of_passing" name="year_of_passing">
                            </div>
                            <div class="input_wrap">
                                <label for="Information">CGPA/Percentage obtained</label>
                                <input type="text" placeholder="" id="CGPA_percentage_obtained" name="CGPA_percentage_obtained">
                            </div>

                        </div>
                        <div class="input_wrap">

                            <button type="button" class="btn btn-dark" id=" addEdu">+ Add new Education</button>
                        </div>
                    </div>
                    <hr class="my-5">
                    <h4><strong>Honors and Awards</strong></h4>
                    <div class="input_wrap">
                        <div class="job">
                            <label for="award">Title of Award</label>
                            <input type="text" placeholder="title" id="title_of_award" name="title_of_award">
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="award">Issued by</label>
                                <input type="text" placeholder="issued_by" id="issued_by" name="issued_by">
                            </div>
                            <div class="input_wrap">
                                <label for="university">Issued In – Year</label>
                                <input type="text" placeholder="year" id="issued_in_year" name="issued_in_year">
                            </div>

                        </div>
                        <div class="input_wrap">

                            <button type="button" class="btn btn-dark">+ Add new Award</button>
                        </div>
                    </div>
                    <hr class="my-5">
                    <h4><strong>Academic Certification</strong></h4>
                    <div class="input_wrap">
                        <div class="job">
                            <label for="certification">Name of the Certificate</label>
                            <input type="text" placeholder="name_of_the_certificate" id="name_of_the_certificate" name="name_of_the_certificate">
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="award">Name of the Issuing Organisation</label>
                                <input type="text" placeholder="issued_by" id="name_of_the_issuing_organisation" name="name_of_the_issuing_organisation">
                            </div>
                            <div class="input_wrap">
                                <label for="start">Date of Issue</label>
                                <input type="date" id="date_of_issue" name="date_of_issue">
                            </div>
                        </div>
                    </div>

                    <hr class="my-5">
                    <h4><strong>Projects/Research Experience</strong></h4>
                    <div class="input_wrap">
                        <div class="job">
                            <label for="title">Project title</label>
                            <input type="text" placeholder="project_title" id="project_title" name="project_title">
                        </div>
                        <div class="input_wrap">
                            <label for="roles">Project Description</label>
                            <textarea name="project_description" id="project_description" placeholder="project_description" cols="82" rows="3" name="roles"></textarea>
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="year">Year</label>
                                <input type="text" placeholder="year" id="year" name="pub_year">
                            </div>

                            <div class="input_wrap">
                                <label for="advisor">Advisor (Name of Faculty/Researcher)</label>
                                <input type="text" placeholder="advisor" id="advisor" name="advisor_pub">
                            </div>
                        </div>
                        <div class="input_wrap">
                            <label for="roles">Use Cases</label>
                            <textarea name="use_cases_pub" id="use_cases" placeholder="use_cases" cols="82" rows="3"></textarea>
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Published">Published In</label>
                                <input type="text" placeholder="published_in" id="published_in" name="published_in_pub">
                            </div>

                            <div class="input_wrap">
                                <label for="Place">Place of the Project (Name of Organisation)</label>
                                <input type="text" placeholder="place_of_project" id="place_of_project" name="place_of_project">
                            </div>
                        </div>
                    </div>
                    <hr class="my-5">
                    <h4><strong>Journal Publications (APA format)</strong></h4>
                    <div class="input_wrap">
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Journal">Journal Papers Accepted</label>
                                <input type="text" placeholder="journal_papers" id="journal_papers_accepted" name="journal_papers_accepted">
                            </div>

                            <div class="input_wrap">
                                <label for="Journal">Journal Papers in Review</label>
                                <input type="text" placeholder="journal_papers_review" id="journal_papers_review" name="journal_papers_review">
                            </div>
                        </div>
                        <div class="input_wrap">
                            <label for="roles">Conference Papers (APA format)</label>
                            <textarea name="conference_papers" id="conference_papers" name="roles" placeholder="conference_papers" cols="82" rows="2"></textarea>
                        </div>
                    </div>
                    <hr class="my-5">
                    <h4><strong>Patents</strong></h4>
                    <div class="input_wrap">
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="lname">Inventor LastName</label>
                                <input type="text" placeholder="last_name" id="inventor_lastname" name="inventor_lastname">
                            </div>

                            <div class="input_wrap">
                                <label for="fname">Inventor FirstName</label>
                                <input type="text" placeholder="first_name" id="inventor_firstname" name="inventor_firstname">
                            </div>
                        </div>
                        <div class="job">
                            <label for="title">“Title of Invention”</label>
                            <input type="text" placeholder="title" id="title_of_invention" name="title_of_invention">
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Patent">Patent office</label>
                                <input type="text" placeholder="patent_office" id="patent_office" name="patent_office">
                            </div>

                            <div class="input_wrap">
                                <label for="Patent">Patent No.</label>
                                <input type="number" placeholder="patent_number" id="patent_number" name="patent_number">
                            </div>
                        </div>
                    </div>
                    <hr class="my-5">
                    <h4><strong>Professional Training</strong></h4>
                    <h5><strong>Seminar or Workshop</strong></h5>
                    <div class="input_wrap">
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Institution">Name of Institution</label>
                                <input type="text" placeholder="name_of_institution" id="name_of_institution" name="name_of_institution">
                            </div>

                            <div class="input_wrap">
                                <label for="location">Location</label>
                                <input type="text" placeholder="ins_location" id="ins_location" name="ins_location">
                            </div>
                        </div>
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Validity">Validity</label>
                                <input type="text" placeholder="validity" id="validity" name="validity">
                            </div>
                            <div class="input_wrap">
                                <label for="date">Date</label>
                                <input type="date" id="date" name="date">
                            </div>
                        </div>
                        <div class="input_wrap">
                            <label for="roles">Description</label>
                            <textarea name="roles" id="ins_description" name="ins_description" placeholder="description" cols="82" rows="3"></textarea>
                        </div>

                    </div>
                    <hr class="my-5">
                    <h4><strong>Professional Affiliations</strong></h4>

                    <div class="input_wrap">
                        <div class="input_grp3">
                            <div class="input_wrap">
                                <label for="Institution">Name of Organization</label>
                                <input type="text" placeholder="name_of_organisation" id="name_of_organization" name="name_of_organization">
                            </div>

                            <div class="input_wrap">
                                <label for="year">Year to year</label>
                                <input type="text" placeholder="year" id="year_to_year" name="year_to_year">
                            </div>
                        </div>
                        <div class="input_wrap">
                            <label for="roles">Description of role or responsibilities, if applicable.</label>
                            <textarea name="roles" id="roles" name="roles" placeholder="description" cols="82" rows="3"></textarea>
                        </div>
                        <div class="input_wrap">

                            <button type="button" class="btn btn-dark">+ Add new Affiliations</button>
                        </div>
                    </div>

                    <hr class="my-5">
                    <div class="input_wrap">

                            <label for="position">Position of Responsibility</label>
                            <input type="text" placeholder="position_of_responsibility" id="position_of_responsibility" name="position_of_responsibility">

                            <label for="position"><br>Extracurricular Activities</label>
                            <input type="text" placeholder="extracurricular_activities" id="extracurricular_activities" name="extracurricular_activities">

                            <div class="input_grp3">
                                <div class="input_wrap">
                                    <label for="lang"><br>Languages</label>
                                    <input type="text" placeholder="languages" id="languages" name="languages">
                                </div>

                                <div class="input_wrap">
                                    <label for="hobbies"><br>Hobbies</label>
                                    <input type="text" placeholder="hobbies" id="hobbies" name="hobbies">
                                </div>
                            </div>

                    </div>


                    <div class="input_wrap text-right">
                        <input type="submit" value="SUBMIT" class="submit_btn" name="submit">
                    </div>
        </div></form>
    </div>


            </div>
          </div>
        </div>
      </div>


    </div>

  </div>

  <style>
    .error {
        color: red;
    }
  </style>

    <script>
      /*function validatePhone(txtPhone) {
        var a = document.getElementById(txtPhone).value;
        var filter = /^((\+*)((0[ -]+)*|(91 )*)(\d{12}|\d{10}))|\d{5}([- ]*)\d{6}$/;
        if (filter.test(a)) {
            return true;
        }
        else {
            return false;
        }
      }*/

            $("#addForm").validate({
            rules: {
                name: {
                    required: true,
                    minlength: 3,
                    maxlength: 1000,
                },
                phone_number: {
                    required: true,
                    minlength: 10,
                    maxlength: 10,
                },
                email_id: {
                    required: true,
                    maxlength: 1000,
                },
                location: {
                    required: true,
                    maxlength: 1000,
                },
                preferred_work_locations: {
                    required: true,
                    maxlength: 1000,
                },
                objective: {
                    required: true,
                    maxlength: 1000,
                },
                job_title: {
                    required: true,
                    maxlength: 1000,
                },
                name_of_organisation: {
                    required: true,
                    maxlength: 1000,
                },
                starting_from: {
                    required: true,
                    date: true,
                },
                ending_in: {
                    required: true,
                    date: true,
                },
                roles: {
                    required: true,
                    maxlength: 1000,
                },
                college_name: {
                    required: true,
                    maxlength: 1000,
                },
                college_university_autonomous: {
                    required: true,
                    maxlength: 1000,
                },
                college_affiliated_to_university: {
                    required: true,
                    maxlength: 1000,
                },
                pg_degree_details: {
                    required: true,
                    maxlength: 1000,
                },
                ug_degree_details: {
                    required: true,
                    maxlength: 1000,
                },
                specialisation: {
                    required: true,
                    maxlength: 1000,
                },
                year_of_passing: {
                    required: true,
                    maxlength: 4,
                    digits: true,
                },
                CGPA_percentage_obtained: {
                    required: true,
                    maxlength: 4,
                    digits: true,
                },
                title_of_award: {
                    required: true,
                    maxlength: 1000,
                },
                issued_by: {
                    required: true,
                    maxlength: 1000,
                },
                issued_in_year: {
                    required: true,
                    maxlength: 4,
                    digits: true,
                },
                name_of_the_certificate: {
                    required: true,
                    maxlength: 1000,
                },
                name_of_the_issuing_organisation: {
                    required: true,
                    maxlength: 1000,
                },
                date_of_issue: {
                    required: true,
                    date: true,
                },
                project_title: {
                    required: true,
                    minlength: 3,
                    maxlength: 13,
                },
                project_description: {
                    required: true,
                    maxlength: 1000,
                },
                pub_year:{
                  required:true,
                  maxlength: 4,
                },
                advisor_pub:{
                  required:true,
                },
                use_cases_pub:{
                  required: true,
                  maxlength: 1000,
                },
                published_in_pub:{
                  required: true,
                },
                place_of_project:{
                  required: true,
                },
                journal_papers_accepted:{
                  required: true,
                },
                journal_papers_review:{
                  required: true,
                },
                conference_papers:{
                  required: true,
                },
                inventor_lastname:{
                  required: true,
                },
                inventor_firstname:{
                  required: true,
                },
                title_of_invention:{
                  required:true,
                },
                patent_office:{
                  required:true,
                },
                patent_number:{
                  required:true,
                },
                name_of_institution:{
                  required:true,
                },
                ins_location:{
                  required:true,
                },
                validity:{
                  required:true,
                },
                name_of_organization:{
                  required:true,
                },
                year_to_year:{
                  required:true,
                },
                position_of_responsibility:{
                  required:true,
                },
                extracurricular_activities:{
                  required:true,
                },
                languages:{
                  required:true,
                },
                hobbies:{
                  required:true,
                },
            },
            messages: {
              name: {
                    required: "Please enter Name",
                    minlength: "Title should be greater than 3 characters",
                    maxlength: "Title should be less than 1000 characters",
                },
                phone_number: {
                    required: "Please enter Name",
                    minlength: "Title should be greater than 10 characters",
                    maxlength: "Title should be less than 13 characters",
                },
                email_id: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                location: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                preferred_work_locations: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                objective: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                job_title: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                name_of_organisation: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                starting_from: {
                    required: "Please enter Name",
                    date: 'Please enter a valid Date',
                },
                ending_in: {
                    required: "Please enter Name",
                    date: 'Please enter a valid Date',
                },
                roles: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                college_name: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                college_university_autonomous: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                college_affiliated_to_university: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                pg_degree_details: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                ug_degree_details: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                specialisation: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                year_of_passing: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 4 characters",
                    digits: 'Please enter Digits',
                },
                CGPA_percentage_obtained: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 4 characters",
                    digits: 'Please enter Digits',
                },
                title_of_award: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                issued_by: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                issued_in_year: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 4 characters",
                    digits: 'Please enter Digits',
                },
                name_of_the_certificate: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                name_of_the_issuing_organisation: {
                    required: "Please enter Name",
                    maxlength: "Title should be less than 1000 characters",
                },
                date_of_issue: {
                    required: "Please enter Name",
                    date: 'Please enter a valid Date',
                },
                project_title:{
                  required: "Please enter Project Title",
                  minlength: "Project Title should be greater than 10 characters",
                  maxlength: "Project Title should be less than 13 characters",
                },
                project_description:{
                  required: "Please enter Description",
                  maxlength: "Project Title should be less than 1000 characters",
                },
                pub_year:{
                  required: "Please enter Year of Publishing",
                  maxlength: "Year of Publishing should be less than 5 characters",
                },
                advisor_pub:{
                  required: "Please enter Advisor",
                },
                use_cases_pub:{
                  required: "Please enter Use Cases",
                  maxlength: "Use Cases should be less than 1000 characters",
                },
                published_in_pub:{
                  required: "Please enter Publisher",
                },
                place_of_project:{
                    required: "Please enter Publishing Location",
                },
                journal_papers_review:{
                  required: "Please enter Jounals in Review",
                },
                conference_papers:{
                  required: "Please enter Conference Papers ",
                },
                journal_papers_accepted:{
                    required: "Please enter Jounals Accepted",
                },
                inventor_lastname:{
                  required: "Please enter Inventor LastName",
                },
                inventor_firstname:{
                  required: "Please enter Inventor FirstName",
                },
                title_of_invention:{
                  required: "Please enter Invention Name",
                },
                patent_office:{
                  required: "Please enter Patent Office",
                },
                patent_number:{
                  required: "Please enter Patent Number",
                },
                name_of_institution:{
                  required: "Please enter Name of Institution",
                },
                ins_location:{
                  required: "Please enter Location",
                },
                validity:{
                  required: "Please enter Validity",
                },
                name_of_organization:{
                  required: "Please enter Name of the Organisation",
                },
                year_to_year:{
                  required: "Please enter Year to Year",
                },
                position_of_responsibility:{
                  required: "Please enter Responsibility",
                },
                extracurricular_activities:{
                  required: "Please enter Extracurricular Activities",
                },
                languages:{
                  required: "Please enter Langauages",
                },
                hobbies:{
                  required: "Please enter Hobbies",
                }

            },
            errorElement : 'div',
            // errorLabelContainer: '.errorTxt',
            errorPlacement: function(error, element) {
                    error.insertAfter(element);
            },
            submitHandler: function (form) {
                form.submit();
            }
            });



      // <!-- Optional JS -->
      //Example starter JavaScript for disabling form submissions if there are invalid fields
      (function() {
        'use strict';
        window.addEventListener('load', function() {
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');
          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
              if (form.checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
              }
              form.classList.add('was-validated');
            }, false);
          });
        }, false);
      })();

    //Capitalize first letter while typing in side of input field
    jQuery(document).ready(function($) {
        $('#addForm').keyup(function(event) {
            var textBox = event.target;
            var start = textBox.selectionStart;
            var end = textBox.selectionEnd;
            textBox.value = textBox.value.charAt(0).toUpperCase() + textBox.value.slice(1);
            textBox.setSelectionRange(start, end);
        });
    });
  </script>
<?php require_once 'requires/end-scripts.php' ?>
</body>

</html>
