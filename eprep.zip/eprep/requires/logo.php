<!-- Brand -->
<div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
          <img src="img/brand/blue.png" class="navbar-brand-img" alt="...">
        </a>
      </div>