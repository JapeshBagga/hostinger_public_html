  <!-- Argon Scripts -->
  <!-- Core -->
  <script src="../vendor/jquery/dist/jquery.min.js"></script>
  <script src="../vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../vendor/js-cookie/js.cookie.js"></script>
  <script src="../vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
  <script src="../vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
  <!-- Optional JS -->
  <script src="../vendor/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="../vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
  <script src="../vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
  <script src="../vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
  <script src="../vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
  <script src="../vendor/datatables.net-select/js/dataTables.select.min.js"></script>
  <script src="../vendor/select2/dist/js/select2.min.js"></script>
  <script src="../vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
  <script src="../vendor/nouislider/distribute/nouislider.min.js"></script>
  <script src="../vendor/quill/dist/quill.min.js"></script>
  <script src="../vendor/dropzone/dist/min/dropzone.min.js"></script>
  <script src="../vendor/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
  <!-- Argon JS -->
  <script src="../js/argon.js?v=1.2.0"></script>
   <!-- Demo JS - remove this in your project -->
   <script src="../js/demo.min.js"></script>