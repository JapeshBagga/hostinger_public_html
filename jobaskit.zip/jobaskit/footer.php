<footer class="mainfooter text-center" role="contentinfo">
  <div class="footer-middle">
  <div class="container">
    <div class="row text-center">
        <div class="col-lg-6 col-md-3 col-sm-3 col-12">
           <!--Column1-->
            <h4>Follow Us</h4>
            <p>Join millions of people who organize work and life with Todoist.</p>
            <ul class="social-network social-circle">
             <li><a href="#" class="icoFacebook" title="Facebook"><i class="fab fa-facebook"></i></a></li>
             <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fab fa-linkedin"></i></a></li>
             <li><a href="#" class="icoFacebook" title="Facebook"><i class="fab fa-instagram"></i></a></li>
             <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fab fa-twitter"></i></a></li>
            </ul>               
        </div>
      <div class="col-lg-2 col-md-3 col-sm-3 col-6">
        <!--Column2-->
        <div class="footer-pad">
          <h4 class="text-left">Features</h4>
          <ul class="list-unstyled text-left">
            <li><a href="#">How It Works</a></li>
            <li><a href="#">For Teams</a></li>
            <li><a href="#"> Templates</a></li>
            <li><a href="#">Pricing</a></li>
          </ul>
        </div>
      </div>
     
      <div class="col-lg-2 col-md-3 col-sm-3 col-6">
        <!--Column3-->
        <div class="footer-pad">
          <h4 class="text-left">Comapny</h4>
          <ul class="list-unstyled text-left">
            <li><a href="#"> We are Hiring</a></li>
            <li><a href="#"> About Us</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Press</a></li>
            <li><a href="#">Twist</a></li>
          </ul>
        </div>
      </div>
      
      <div class="col-lg-2 col-md-3 col-sm-3 col-6">
        <!--Column4-->
        <div class="footer-pad">
          <h4 class="text-left">Resources</h4>
          <ul class="list-unstyled text-left">
            <li><a href="#"> Productivity Methods</a></li>
            <li><a href="#"> Channel Partners</a></li>
            <li><a href="#">  Developer APIs</a></li>
            <li><a href="#">Download Apps</a></li>
            <li><a href="#"> Refer a Friend</a></li>
            <li><a href="#"> Help Center</a></li>
            <li><a href="#"> Integrations</a></li>
          </ul>
        </div>
      </div>
    </div>
   </div>
  </div>
</footer>