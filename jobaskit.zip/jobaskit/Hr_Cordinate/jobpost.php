<?php
	if(isset($_POST["submit"])){
		$job_title=$_POST["job_title"];
	 	$skills=$_POST["skills"];
		$location=$_POST["location"];
		$start_date=$_POST["start_date"];
		$duration=$_POST["duration"];
		$job_type=$_POST["job_type"];
		$resume_time=$_POST["resume_time"];
		$description=$_POST["description"];
		$Stipend=$_POST["Stipend"];
		$openings=$_POST["openings"];
		$no_application=$_POST["no_application"];
		$job_intern=$_POST["job_intern"];

		$servername = "localhost";
		$username = "root";
		$password1 = "";
		// Create connection
		$conn = new mysqli($servername, $username, $password1,"jobaskit");
		// Check connection
		if ($conn->connect_error) {
			  die("Connection failed: " . $conn->connect_error);
		}
		
		 	$sql = "INSERT INTO job (job_title, skills, location, start_date,duration, job_type, resume_time, description,Stipend, openings,no_application,job_intern) VALUES ('".$job_title."','".$skills."', '".$location."', '".$start_date."','".$duration."','".$job_type."','".$resume_time."', '".$description."','".$Stipend."', '".$openings."','".$no_application."','".$job_intern."')";
			if ($conn->query($sql) === TRUE) {
		  header("Location: index.php");
		} else {
		  echo "Error: " . $sql . "<br>" . $conn->error;
		}
		$conn->close();		
		
	}