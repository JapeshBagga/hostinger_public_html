<?php
	
	Class Home{
		public function index()
		{
			header("Location: index.php");	
		}
		public function login()
		{
			session_start();
			// $_SESSION["role_id"] = "college";
			// print_r($_SESSION);exit;
			if (isset($_SESSION["role_id"])) {
			
			if ($_SESSION["role_id"] == "college" ){
				header("Location: collegedash.html");		
			}
			if ($_SESSION["role_id"] == "company" ){		
				header("Location: companydash.html");	
			}
			}else if(isset($_POST["work"])){
				if ($_POST["work"]=="Login"){
					$servername = "localhost";
					$username = "root";
					$password = "";
					// Create connection
					$conn = new mysqli($servername, $username, $password,"jobaskit");
					// Check connection
					if ($conn->connect_error) {
					  die("Connection failed: " . $conn->connect_error);
					}
					$email=$_POST['email'];
					 $pass=$_POST['password'];
					echo $sql = "SELECT * FROM users WHERE email='".$email."' and password='".$pass."'";
					$result = $conn->query($sql);
					if ($result->num_rows > 0) {
					  // output data of each row
					  while($row = $result->fetch_assoc()) {
						echo $_SESSION["role_id"]=$row["role_id"];
						// $_SESSION["type"]="company";
						echo 'success';
					  }
					} 
					else {
					  echo "0 results";
					}
					$conn->close();
				}
			}else{
				header("Location: signin.php");
			}

		}

		public function dashboard(){
			if(isset($_SESSION["role_id"])) {
				if ($_SESSION["role_id"] == "college" ){
					header("Location: collegedash.html");		
				}
				if ($_SESSION["role_id"] == "company" ){		
					header("Location: companydash.html");	
				}
			}else{
				$home->login();
			}
			
		}
		public function signup(){		

			if(isset($_POST["work"])){
				if ($_POST["work"]=="Signup"){
					 $role=$_POST["role_id"]; 
					if ($role=='college') {
						$role=$_POST["role_id"];
					 	$userName=$_POST["colName"];
						$Contact=$_POST["collegeContact_Number"];
						$email=$_POST["collegeemail"];
						$name=$_POST["collegename"];
						$type=$_POST["Universitytype"];
						$Country=$_POST["collegeCountry"];
						$State=$_POST["collegeState"];
						$city=$_POST["collegecity"];
						$street=$_POST["collegestreet"];
						$password=$_POST["collegepassword"];
						$servername = "localhost";
						$username = "root";
						$password1 = "";
						// Create connection
						$conn = new mysqli($servername, $username, $password1,"jobaskit");
						// Check connection
						if ($conn->connect_error) {
							  die("Connection failed: " . $conn->connect_error);
						}
						$sql = "SELECT * FROM users WHERE email='".$email."'";
						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							 echo "You're already registered, Please Log in";
						} else {
						 	$sql = "INSERT INTO users (role_id, userName, Contact, email,name, type, Country, State,city, street,password) VALUES ('college','".$userName."', '".$Contact."', '".$email."','".$name."','".$type."','".$Country."', '".$State."','".$city."', '".$street."','".$password."')";
							if ($conn->query($sql) === TRUE) {
								$sql = "SELECT * FROM users WHERE email='".$email."'";
								$result = $conn->query($sql);
								if ($result->num_rows > 0) {
									while($row = $result->fetch_assoc()) {
									$_SESSION["role_id"]=$row["role_id"];
									// $_SESSION["type"]="company";
									$this->dashboard();
									}
								} 
								else{
								echo "An unexpected error occoured";
								}
							} else {
							 	echo "Error: " . $sql . "<br>" . $conn->error;
							}
						}
						$conn->close();
					}
					if ($role=='company') {
					 	$userName=$_POST["comName"];
						$Contact=$_POST["companyContactNumber"];
						$email=$_POST["companyemail"];
						$name=$_POST["comapnyname"];
						$companyucc=$_POST["companyucc"];
						$type=$_POST["Companytype"];
						$Country=$_POST["companyCountry"];
						$State=$_POST["companyState"];
						$city=$_POST["companycity"];
						$street=$_POST["companystreet"];
						$password=$_POST["companypassword"];


						$servername = "localhost";
						$username = "root";
						$password1 = "";
						// Create connection
						$conn = new mysqli($servername, $username, $password1,"jobaskit");
						// Check connection
						if ($conn->connect_error) {
							  die("Connection failed: " . $conn->connect_error);
						}
						$sql = "SELECT * FROM users WHERE email='".$email."'";
						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
							 echo "You're already registered, Please Log in";
						} else {
							$sql = "INSERT INTO users(role_id, userName, Contact, email,name, type, Country, State,city, street,password,companyucc) VALUES ('company','".$userName."', '".$Contact."', '".$email."','".$name."','".$type."','".$Country."', '".$State."','".$city."', '".$street."','".$password."','".$companyucc."')";
							if ($conn->query($sql) === TRUE) {
								$sql = "SELECT * FROM users WHERE email='".$email."'";
								$result = $conn->query($sql);
								if ($result->num_rows > 0) {
									while($row = $result->fetch_assoc()) {
									$_SESSION["role_id"]=$row["role_id"];
									$this->dashboard();
									}
								} 
								else{
									echo "An unexpected error occoured";
								}
							} else {
								 echo "Error: " . $sql . "<br>" . $conn->error;
							}
						}
						$conn->close();
					}
					
				}
			}else{
				header("Location: signup.php");
			}
		}
}
	$home=new Home();
	
	if(isset($_POST["work"])){
		if($_POST["work"]=="Login"){
			$home->login();
		}else if($_POST["work"]=="Signup") {
			$home->signup();
		}
	}else if(isset($_GET["login_click"])){
		$home->login();
	}else if(isset($_GET["logout_click"])){
		$home->login();
	}else if(isset($_GET["signup_click"])){
		$home->signup();
	}
	//please maintain last
	else if(isset($_SESSION["role_id"])) {
		$home->dashboard();
	}else{
		$home->index();
	}