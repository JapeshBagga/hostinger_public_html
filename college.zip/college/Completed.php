<!doctype html>
<?php
    require "php/connect.php";
    require "php/messageDisp.php";
    require "php/preCommonHeader.php";
    $hcompleted = "class='mm-active'";
    require "php/commonHeader.php";
?>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <div class="main-card mb-3 card">
                        <div class="card-body"><h5 class="card-title">Completed</h5>
                            <div class="mb-3 progress" style="height: 40px;">
                                <div class="progress-bar progress-bar-animated bg-success " role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;  "><h5>Adobe</h5></div>
                            </div>
                            <div class="mb-3 progress" style="height: 40px;">
                                <div class="progress-bar progress-bar-animated bg-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;  "><h5>Mahendra</h5></div>
                            </div>
                            <div class="mb-3 progress" style="height: 40px;">
                                <div class="progress-bar progress-bar-animated bg-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;  "><h5>UpGrad</h5></div>
                            </div>
                            <div class="mb-3 progress" style="height: 40px;">
                                <div class="progress-bar progress-bar-animated bg-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;  "><h5>Urban Company</h5></div>
                            </div>
                            <div class="mb-3 progress" style="height: 40px;">
                                <div class="progress-bar progress-bar-animated bg-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;  "><h5>Atlas Copco</h5></div>
                            </div>
                            <div class="mb-3 progress" style="height: 40px;">
                                <div class="progress-bar progress-bar-animated bg-success" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;  "><h5>L&T</h5></div>
                            </div>
                          
                        </div>
                    </div>
                    <!-- <div class="main-card mb-3 card">
                        <div class="card-body"><h5 class="card-title">Completed</h5>
                            <div class="mb-3 progress">
                                <div class="progress-bar progress-bar-animated bg-success progress-bar-striped" role="progressbar" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">Planet Spark</div>
                            </div>
                            <div class="mb-3 progress">
                                <div class="progress-bar progress-bar-animated bg-success progress-bar-striped" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">Planet Spark</div>
                            </div>
                            <div class="mb-3 progress">
                                <div class="progress-bar progress-bar-animated bg-success progress-bar-striped" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">Planet Spark</div>
                            </div>
                            <div class="mb-3 progress">
                                <div class="progress-bar progress-bar-animated bg-success progress-bar-striped" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">Planet Spark</div>
                            </div>
                            <div class="mb-3 progress">
                                <div class="progress-bar progress-bar-animated bg-success progress-bar-striped" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">Planet Spark</div>
                            </div>
                        </div>
                    </div> -->
                   
                
                    <?php
    require "php/commonEnd.php";
    
?>