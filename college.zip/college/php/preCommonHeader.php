<?php
$haccReq = "";
$hcomProf = "";
$hcompleted = "";
$hfeedback = "";
$hindex = "";
$hjobList = "";
$hnewComp = "";
$hpendingConn = "";
$hprocess = "";
$hrecentView = "";
$hstudTable = "";
$hvalid = "";
$hpending = "";
?>