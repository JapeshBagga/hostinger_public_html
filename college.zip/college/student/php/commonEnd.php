<div class="app-wrapper-footer">
                    <div class="app-footer">
                        <div class="app-footer__inner">
                            <p>All rights Reversed</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="./assets/scripts/main.js"></script>
    <script src='https://code.jquery.com/jquery-3.5.1.js'></script>
    <script src='https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js'></script>
    <script src='https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js'></script>
   <script>
       $(document).ready(function() {
          $('#example').DataTable();
        } );
   </script>
</body>

</html>