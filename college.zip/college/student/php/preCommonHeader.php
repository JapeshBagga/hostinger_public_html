<?php
$hcollFeed = "";
$happJob = "";
$hcompleted = "";
$hfeedback = "";
$hfcontrol = "";
$hfvalid = "";
$hindex = "";
$hjobList = "";
$hpending = "";
$hprocess = "";
?>