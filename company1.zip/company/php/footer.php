<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left">
                <p>All rights Reversed</p>
                    <button type="button" class="btn mr-2 mb-2 btn-success" style="position: absolute; right: 15px; font-size: 16px;" onclick="location.href='new_company.php';">Make us connect with campus</button>
            </div>
        </div>
    </div>
</div>